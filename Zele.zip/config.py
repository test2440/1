from sample_config import Config


class Development(Config):
    # ضـع اكـوادك تحت مكـان الكـلام العـربي  .. امسـح الكلام العربي اللي بين " " فقـط وضع اكـوادك
    APP_ID = 29594268 #ضع كود الايبي ايدي الصغيـر مكان الرقم 6 نسخ لصق   
    API_HASH = "c6308bde7547070c42a539192ae0b857"
    ALIVE_NAME = "𓆩 𝐌𝐀𝐘𝐅𝐑 𓆪"
    DB_URI = "postgresql://postgres:gnazh01@localhost:5432/aljoker"
    STRING_SESSION = "1BJWap1wBuzcqV74tuedNm63uPhNGS6qgjpf98gKntpcmOoRhck46nxuOEqx0U5JYCiK2ZECRTSb4Uel4iB3FhAQPG_cHpj235W0_Dulas1bxdnlkY4jCyG5Cb-uUlmsqxRJTgRKCJmNZOCM-rH6lelOkGlUEtFIpAY2KPfrXtO1OIETKI52DRfZ5e2n5SR4yfa8V6cnzm5E64YzkuPG_mq56itQAzs9_lxY57qL3p08_c4I6AGd_ljWe2ubM09YpfbyQKkcf1qyrcbeY49r-fsTTreAsX9pVXMLwJ6mcE6X03a_jvgnPc9xhoOyoI-cjDZ-S2mB4DERGeXBhQLl8qvy3EJ4Y2Gg="
    TG_BOT_TOKEN = "7985752963:AAHYNIStmQVywCH0pG1tH6uYpm1bQ5PFJoM"
    PRIVATE_GROUP_BOT_API_ID = -1002489173581   # ضـع ايـدي كـروب السجـل بجـانب العـدد -100 لا تمسـح العـدد هـذا
    COMMAND_HAND_LER = "."  # اتركهــا كمـا هـي
    SUDO_COMMAND_HAND_LER = "."  # اتركهــا كمـا هـي
    TZ = "Asia/Baghdad"  # اتركهــا كمـا هـي
