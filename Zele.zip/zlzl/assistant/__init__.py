from zlzl import BOTLOG, BOTLOG_CHATID, zedub

from ..Config import Config
from ..core.inlinebot import *
